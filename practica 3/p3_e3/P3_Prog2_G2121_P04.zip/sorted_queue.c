#include "sorted_queue.h"
#include <stdio.h>
#include <stdlib.h>

/*--------------------------------------------------------------------------*/
SortedQueue *squeue_new() {
  return queue_new();  
}

/*--------------------------------------------------------------------------*/
void squeue_free(SortedQueue *q) {
  queue_free(q);
}

/**
 * @brief  Inserta un elemento en la cola ordenada.
 *
 * TO-DO: Incluye aqui el pseudocodigo del algoritmo implementado.
 * 
 * @param q, puntero a la cola.
 * @param ele, puntero al elemento a insertar.
 * @param pcmp, puntero a la funcion de comparacion.
 *
 * @return OK si la insercion se realiza con exito, ERROR en caso contrario.
 **/
int int_print(FILE *f, const void *x);

Status squeue_push(SortedQueue *q, void *ele, p_queue_ele_cmp pcmp) {
  Status st = OK;
  int i=0;
  /*Queue* qord=NULL;*/
  void* aux = NULL;
  /* TO DO: Completa el codigo de esta funcion*/
  if(!q||!ele||!pcmp) return ERROR;

  if(queue_isEmpty(q)==TRUE){
    return queue_push(q,ele);
  }
  else{

    for(i=0; (pcmp(queue_getFront(q),ele) <= 0 && st == OK) && i < queue_size(q); i++){
      aux = queue_pop(q);
      st = queue_push(q,aux);
    }

    st=queue_push(q,ele);


    for(i=0; pcmp(queue_getFront(q),ele) > 0 && st == OK && i<queue_size(q); i++){
      aux = queue_pop(q);
      st = queue_push(q,aux);
    }
  }

  return st;
}

/*--------------------------------------------------------------------------*/
void *squeue_pop(SortedQueue *q) {
  return queue_pop(q);
}

/*--------------------------------------------------------------------------*/
void *squeue_getFront(const SortedQueue *q) {
  return queue_getFront(q);
}

/*--------------------------------------------------------------------------*/
void *squeue_getBack(const SortedQueue *q) {
  return queue_getBack(q);
}

/*--------------------------------------------------------------------------*/
Bool squeue_isEmpty(const SortedQueue *q) {
  return queue_isEmpty(q);
}

/*--------------------------------------------------------------------------*/
size_t squeue_size(const SortedQueue *q) {
  return queue_size(q);
}

/*--------------------------------------------------------------------------*/
int squeue_print(FILE *fp, const SortedQueue *q, p_queue_ele_print f) {
  return queue_print(fp, q, f);
}

